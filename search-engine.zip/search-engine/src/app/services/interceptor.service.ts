import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { APP_CONSTANTS } from '../app.constant';

@Injectable()
export class InterceptorService implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.url.includes('newsapi')) {
      const newRequest = req.clone({
        url: req.url + `&apiKey=${APP_CONSTANTS.news_api_key}`
      });
      return next.handle(newRequest);
    }
    return next.handle(req);
  }

}
