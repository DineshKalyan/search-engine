import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { NewsData, SearchService } from '../../services/search.service';

import { APP_CONSTANTS } from 'src/app/app.constant';

@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent implements OnInit {
  searchTerm: string = '';
  searchData = <NewsData | any>[];
  currentPage = 1;
  loading = false;
  recordsPerPage = APP_CONSTANTS.records_per_page;
  routeSubscrition: Subscription = new Subscription;
  searchSubscrition: Subscription = new Subscription;

  constructor(private route: ActivatedRoute, private searchService: SearchService, private router: Router) { }

  ngOnInit(): void {
    this.routeSubscrition = this.route.queryParams.subscribe(params => {
      this.searchTerm = params['searchTerm'];
    });
    this.searchSubscrition = this.searchService.searchResults.subscribe((result: any) => {
      if (!this.searchService.searchTriggered) {
        this.loading = true;
        this.searchService.fetchSearchResults(this.searchTerm);
        return;
      }
      if (!result || !result.totalResults || result.totalResults.length === 0) {
        this.searchData = [];
      } else {
        this.searchData = result.articles;
      }
      this.loading = false;
    });
  }

  ngOnDesroy() {
    this.routeSubscrition.unsubscribe();
    this.searchSubscrition.unsubscribe();
  }

  chipSelected(keyword: string) {
    this.searchTerm = keyword;
    this.currentPage = 1;
    this.loading = true;
    this.searchService.fetchSearchResults(this.searchTerm);
  }

  onBack() {
    this.router.navigateByUrl('/');
  }

}
