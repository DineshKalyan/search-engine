import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';

@Component({
  selector: 'app-search-item',
  templateUrl: './search-item.component.html',
  styleUrls: ['./search-item.component.scss']
})
export class SearchItemComponent implements OnChanges {
  keywords: string[] = [];
  @Input() searchItem: any;
  @Output() chipSelected = new EventEmitter();

  constructor() { }

  ngOnChanges(): void {
    this.keywords.push(this.searchItem.source.name);
    const content = this.searchItem.content.split(',');
    if (content.length > 0)
      this.keywords.push(content[0].slice(0, 10));
  }

  clickKeyword(keyword: string) {
    this.chipSelected.next(keyword);
  }

}
