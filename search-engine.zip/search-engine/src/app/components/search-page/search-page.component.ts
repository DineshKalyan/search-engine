import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { NewsData, SearchService } from 'src/app/services/search.service';
import { LoggerService } from '../../services/logger.service';

@Component({
  selector: 'app-search-page',
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.scss']
})
export class SearchPageComponent implements OnInit {
  searchTerm = '';
  noSearchResult = false;
  loading = false;
  searchSubscrition: Subscription = new Subscription;

  constructor(private logger: LoggerService, private searchService: SearchService, private router: Router) { }

  ngOnInit(): void {
    this.searchService.searchResults.subscribe((result: NewsData | any) => {
      if (!this.searchTerm) return;
      this.loading = false;
      this.noSearchResult = !result || !result.totalResults || result.totalResults.length === 0;
      if (!this.noSearchResult)
        this.router.navigate(['/search-results'], { queryParams: { searchTerm: this.searchTerm } });
    });
  }

  ngOnDesroy() {
    this.searchSubscrition.unsubscribe();
  }

  onSearch() {
    this.noSearchResult = false;
    this.loading = true;
    this.logger.log(`Searched for - ${this.searchTerm}`);
    this.searchService.fetchSearchResults(this.searchTerm);
  }

}
