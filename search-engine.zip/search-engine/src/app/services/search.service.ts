import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';

import { LoggerService } from './logger.service';
import { APP_CONSTANTS } from '../app.constant';

export interface NewsData {
  status: string;
  totalResults: number;
  articles: Array<any>;
}

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  searchResults = new BehaviorSubject(<NewsData | null>null);
  searchTriggered = false;

  constructor(private http: HttpClient, private logger: LoggerService) { }

  fetchSearchResults(searchTerm: string) {
    this.searchTriggered = true;
    this.http.get(`https://newsapi.org/v2/everything?q=${searchTerm}`)
      .subscribe({
        next: (data: NewsData | any) => { this.searchResults.next(data) },
        error: (err) => {
          // this.searchResults.next({});
          this.searchResults.next(APP_CONSTANTS.temp_data); // For hosting application in domain: Testing purpose
          this.logger.error(`News API Error: ${err}`);
        }
      });
  }

}
